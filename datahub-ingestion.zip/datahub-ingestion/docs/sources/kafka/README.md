Support exists for both Apache Kafka and Confluent Cloud.
