## Concept mapping 

| Power BI                  | Datahub             |                                                                                               
| ------------------------- | ------------------- |
| `Dashboard`               | `Dashboard`         |
| `Dataset, Datasource`     | `Dataset`           |
| `Tile`                    | `Chart`             |
| `Report.webUrl`           | `Chart.externalUrl` |
| `Workspace`               | `N/A`               |
| `Report`                  | `N/A`               |

If Tile is created from report then Chart.externalUrl is set to Report.webUrl.
