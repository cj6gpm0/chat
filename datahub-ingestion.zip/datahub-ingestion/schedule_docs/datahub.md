# Using DataHub

[UI Ingestion](../../docs/ui-ingestion.md) can be used to schedule metadata ingestion through DataHub.